import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.161.0/build/three.module.js";

const overlayEl = document.getElementById("overlay");
const overlayEyebrowEl = document.getElementById("overlay-eyebrow");
const overlayTitleEl = document.getElementById("overlay-title");
const overlayTextEl = document.getElementById("overlay-text");
const startBtnEl = document.getElementById("start-btn");
const objectiveEl = document.getElementById("objective");
const healthEl = document.getElementById("health");
const statusEl = document.getElementById("status");
const promptEl = document.getElementById("prompt");
const crosshairEl = document.getElementById("crosshair");

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x05070d);
scene.fog = new THREE.Fog(0x05070d, 10, 88);

const camera = new THREE.PerspectiveCamera(72, window.innerWidth / window.innerHeight, 0.1, 250);
camera.rotation.order = "YXZ";

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 0.86;
document.body.appendChild(renderer.domElement);

scene.add(new THREE.AmbientLight(0x4c577a, 0.3));
const moonLight = new THREE.DirectionalLight(0x9fc1ff, 0.45);
moonLight.position.set(-12, 20, -18);
scene.add(moonLight);

const flashlight = new THREE.SpotLight(0xeaf3ff, 2.2, 24, Math.PI / 7, 0.42, 1);
const flashlightTarget = new THREE.Object3D();
scene.add(flashlightTarget);
flashlight.target = flashlightTarget;
camera.add(flashlight);
camera.add(new THREE.PointLight(0x7dcfff, 0.38, 10));
scene.add(camera);

const world = new THREE.Group();
const decor = new THREE.Group();
scene.add(world);
scene.add(decor);

const solids = [];
const colliders = [];
const interactables = [];
const ceilingLights = [];

const raycaster = new THREE.Raycaster();
const lineRaycaster = new THREE.Raycaster();
const centerScreen = new THREE.Vector2(0, 0);
const tmpVec3 = new THREE.Vector3();
const tmpVec3B = new THREE.Vector3();
const tmpForward = new THREE.Vector3();

const geometryCache = new Map();
function boxGeometry(w, h, d) {
  const key = `${w}:${h}:${d}`;
  if (!geometryCache.has(key)) geometryCache.set(key, new THREE.BoxGeometry(w, h, d));
  return geometryCache.get(key);
}

function material(color, options = {}) {
  return new THREE.MeshStandardMaterial({
    color,
    roughness: options.roughness ?? 0.9,
    metalness: options.metalness ?? 0,
    emissive: options.emissive ?? 0x000000,
    emissiveIntensity: options.emissive ? options.emissiveIntensity ?? 0.35 : 0,
    transparent: options.opacity !== undefined && options.opacity < 1,
    opacity: options.opacity ?? 1,
  });
}

function addMesh(geom, mat, x, y, z, rx = 0, ry = 0, rz = 0, parent = world) {
  const mesh = new THREE.Mesh(geom, mat);
  mesh.position.set(x, y, z);
  mesh.rotation.set(rx, ry, rz);
  parent.add(mesh);
  return mesh;
}

function addSolidBox(x, y, z, w, h, d, color, options = {}) {
  const mesh = addMesh(boxGeometry(w, h, d), material(color, options), x, y, z);
  mesh.visible = options.visible !== false;
  solids.push(mesh);
  colliders.push({ mesh, w, d, enabled: true });
  return mesh;
}

function addDecorBox(x, y, z, w, h, d, color) {
  return addMesh(boxGeometry(w, h, d), material(color), x, y, z, 0, 0, 0, decor);
}

function wallXSegment(x1, x2, z, color, height = 5.8) {
  return addSolidBox((x1 + x2) / 2, 2.9, z, Math.abs(x2 - x1), height, 0.8, color);
}

function wallZSegment(x, z1, z2, color, height = 5.8) {
  return addSolidBox(x, 2.9, (z1 + z2) / 2, 0.8, height, Math.abs(z2 - z1), color);
}

function createCeilingLight(x, z, intensity = 1.1, color = 0xffe0a8) {
  const bulb = new THREE.Mesh(
    new THREE.SphereGeometry(0.16, 10, 8),
    material(color, { emissive: color, emissiveIntensity: 0.9, roughness: 0.4 }),
  );
  bulb.position.set(x, 5.66, z);
  decor.add(bulb);
  const light = new THREE.PointLight(color, intensity, 12, 2);
  light.position.set(x, 5.42, z);
  scene.add(light);
  ceilingLights.push({ light, baseIntensity: intensity, phase: Math.random() * Math.PI * 2 });
}

function addPipe(x, z, length, color = 0x3b4758) {
  const pipe = new THREE.Mesh(
    new THREE.CylinderGeometry(0.1, 0.1, length, 10),
    material(color, { roughness: 0.68, metalness: 0.2 }),
  );
  pipe.rotation.z = Math.PI / 2;
  pipe.position.set(x, 5.45, z);
  decor.add(pipe);
}

const state = {
  running: false,
  paused: false,
  over: false,
  win: false,
  gateOpen: false,
  health: 5,
  maxHealth: 5,
  power: 0,
  enemyMode: "patrol",
  enemyDamageCooldown: 0,
  toastText: "",
  toastTimer: 0,
  focused: null,
  beamTimer: 0,
  beamTarget: new THREE.Vector3(),
};

const keys = {
  KeyW: false,
  KeyA: false,
  KeyS: false,
  KeyD: false,
  ShiftLeft: false,
  ShiftRight: false,
};

const PLAYER_RADIUS = 0.45;
const PLAYER_EYE_HEIGHT = 1.72;
const MOVE_SPEED = 4.5;
const SPRINT_MULTIPLIER = 1.55;
const INTERACT_DISTANCE = 3.1;

const beam = new THREE.Line(
  new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]),
  new THREE.LineBasicMaterial({ color: 0xff6a73, transparent: true, opacity: 0.9 }),
);
beam.visible = false;
scene.add(beam);

addSolidBox(4, -0.5, 5, 78, 1, 22, 0x171a23, { roughness: 1 });
addSolidBox(4, 6.18, 5, 78, 0.8, 22, 0x090b10, { roughness: 0.95 });
wallXSegment(-31, 41, -5.5, 0x252b39);
wallXSegment(-31, -22, 5.5, 0x252b39);
wallXSegment(-14, -4, 5.5, 0x252b39);
wallXSegment(4, 14, 5.5, 0x252b39);
wallXSegment(22, 32, 5.5, 0x252b39);
wallXSegment(34, 41, 5.5, 0x252b39);

const roomColors = [0x38242f, 0x233841, 0x303a27];
const roomXs = [-18, 0, 18];
for (let i = 0; i < roomXs.length; i += 1) {
  const cx = roomXs[i];
  const color = roomColors[i];
  wallZSegment(cx - 4.8, 5.5, 15.5, color);
  wallZSegment(cx + 4.8, 5.5, 15.5, color);
  wallXSegment(cx - 4.8, cx + 4.8, 15.5, color);
  addDecorBox(cx - 2.8, 0.6, 7.2, 1.2, 1.2, 1.2, 0x58403a);
  addDecorBox(cx + 2.6, 0.45, 12.2, 1.0, 0.9, 1.0, 0x5e4650);
}

for (let x = -26; x <= 30; x += 8) createCeilingLight(x, -1.5, 1.1 + Math.random() * 0.2, 0xfff1cf);
for (const cx of roomXs) createCeilingLight(cx, 10.8, 0.8, 0xffda9b);
addPipe(-6, -3.7, 62);
addPipe(-6, 3.7, 62);

function flashBeam(color, target) {
  state.beamTarget.copy(target);
  state.beamTimer = 0.16;
  beam.material.color.setHex(color);
  beam.visible = true;
}

function showToast(text, duration = 1.1) {
  state.toastText = text;
  state.toastTimer = duration;
  promptEl.textContent = text;
  promptEl.classList.remove("hidden");
}

function createCore(name, color, x, z) {
  const pedestal = new THREE.Mesh(
    new THREE.CylinderGeometry(0.44, 0.56, 0.42, 10),
    material(0x3b4456, { roughness: 0.85, metalness: 0.12 }),
  );
  pedestal.position.set(x, 0.21, z);
  scene.add(pedestal);

  const core = new THREE.Mesh(
    new THREE.SphereGeometry(0.34, 16, 12),
    material(color, { emissive: color, emissiveIntensity: 1.15, roughness: 0.25 }),
  );
  core.position.set(x, 1.0, z);
  scene.add(core);

  const halo = new THREE.Mesh(
    new THREE.TorusGeometry(0.48, 0.06, 8, 14),
    material(color, { emissive: color, emissiveIntensity: 0.6, roughness: 0.3 }),
  );
  halo.rotation.x = Math.PI / 2;
  halo.position.set(x, 1.0, z);
  scene.add(halo);

  const light = new THREE.PointLight(color, 1.5, 6, 2);
  light.position.set(x, 1.45, z);
  scene.add(light);

  const item = {
    type: "core",
    name,
    mesh: core,
    light,
    halo,
    pedestal,
    range: INTERACT_DISTANCE,
    collected: false,
    prompt: () => `${name} al`,
    onInteract() {
      if (item.collected || state.over || state.win) return;
      item.collected = true;
      core.visible = false;
      halo.visible = false;
      light.visible = false;
      state.power += 1;
      flashBeam(color, core.position);
      showToast(`${name} alindi`);
      updateHudStatus();
    },
  };
  interactables.push(item);
}

createCore("Kirmizi cekirdek", 0xff4b52, -18, 11.2);
createCore("Turkuaz cekirdek", 0x55d9ff, 0, 11.2);
createCore("Sari cekirdek", 0xffd84f, 18, 11.2);

const gateCollider = addSolidBox(39.4, 2.4, 0, 0.82, 4.8, 10.8, 0x0d121a, { opacity: 0.06, roughness: 1 });
const gateGroup = new THREE.Group();
gateGroup.position.set(39.4, 0, 0);
scene.add(gateGroup);
for (let z = -4.2; z <= 4.2; z += 1.5) {
  const bar = new THREE.Mesh(
    new THREE.BoxGeometry(0.16, 4.5, 0.34),
    material(0x546575, { roughness: 0.82, metalness: 0.35 }),
  );
  bar.position.set(0, 2.25, z);
  gateGroup.add(bar);
}
const gateTop = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.34, 10.8), material(0x546575, { roughness: 0.82, metalness: 0.35 }));
gateTop.position.set(0, 4.45, 0);
gateGroup.add(gateTop);

const escapeLight = new THREE.PointLight(0x8de9ff, 0.02, 18, 2);
escapeLight.position.set(44.5, 2.1, 0);
scene.add(escapeLight);

const exitPanel = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.9, 0.42), material(0x273142, { roughness: 0.8, metalness: 0.1 }));
exitPanel.position.set(35.6, 1.05, 0.7);
scene.add(exitPanel);
const exitButton = new THREE.Mesh(
  new THREE.BoxGeometry(0.2, 0.2, 0.2),
  material(0xff5058, { emissive: 0xff5058, emissiveIntensity: 0.8, roughness: 0.25 }),
);
exitButton.position.set(35.74, 1.23, 0.7);
scene.add(exitButton);

function createMonster() {
  const group = new THREE.Group();
  group.position.set(-10, 0, 0);
  scene.add(group);

  const bodyMat = material(0x2d8be2, { roughness: 0.8, emissive: 0x081221, emissiveIntensity: 0.2 });
  const accentMat = material(0x112235, { roughness: 0.92 });
  const eyeMat = material(0xff4960, { emissive: 0xff4960, emissiveIntensity: 1.5, roughness: 0.2 });

  const torso = new THREE.Mesh(new THREE.BoxGeometry(1.35, 1.75, 0.9), bodyMat);
  torso.position.set(0, 1.35, 0);
  group.add(torso);

  const head = new THREE.Mesh(new THREE.BoxGeometry(1.05, 1.0, 1.0), bodyMat);
  head.position.set(0, 2.55, 0);
  group.add(head);

  const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.16, 0.12), accentMat);
  mouth.position.set(0, 2.28, 0.52);
  group.add(mouth);

  const eyeL = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.13, 0.08), eyeMat);
  eyeL.position.set(-0.22, 2.68, 0.5);
  group.add(eyeL);
  const eyeR = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.13, 0.08), eyeMat);
  eyeR.position.set(0.22, 2.68, 0.5);
  group.add(eyeR);

  const armGeo = new THREE.BoxGeometry(0.22, 1.95, 0.22);
  const leftArm = new THREE.Mesh(armGeo, bodyMat);
  leftArm.position.set(-0.88, 1.55, 0);
  group.add(leftArm);
  const rightArm = new THREE.Mesh(armGeo, bodyMat);
  rightArm.position.set(0.88, 1.55, 0);
  group.add(rightArm);

  const legGeo = new THREE.BoxGeometry(0.28, 1.1, 0.28);
  const legL = new THREE.Mesh(legGeo, accentMat);
  legL.position.set(-0.32, 0.45, 0);
  group.add(legL);
  const legR = new THREE.Mesh(legGeo, accentMat);
  legR.position.set(0.32, 0.45, 0);
  group.add(legR);

  const glow = new THREE.PointLight(0x75a8ff, 0.65, 8, 2);
  group.add(glow);
  return { group, pathIndex: 0, bob: Math.random() * Math.PI * 2 };
}

const monster = createMonster();
const monsterPath = [
  new THREE.Vector2(-24, 0),
  new THREE.Vector2(-11, 0),
  new THREE.Vector2(2, 0),
  new THREE.Vector2(16, 0),
  new THREE.Vector2(28, 0),
  new THREE.Vector2(10, 0),
  new THREE.Vector2(-4, 0),
];

const state = {
  running: false,
  paused: false,
  over: false,
  win: false,
  gateOpen: false,
  health: 5,
  maxHealth: 5,
  power: 0,
  enemyMode: "patrol",
  enemyDamageCooldown: 0,
  toastText: "",
  toastTimer: 0,
  focused: null,
  beamTimer: 0,
  beamTarget: new THREE.Vector3(),
};

const keys = {
  KeyW: false,
  KeyA: false,
  KeyS: false,
  KeyD: false,
  ShiftLeft: false,
  ShiftRight: false,
};

const beam = new THREE.Line(
  new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]),
  new THREE.LineBasicMaterial({ color: 0xff6a73, transparent: true, opacity: 0.9 }),
);
beam.visible = false;
scene.add(beam);

function updateHudStatus() {
  objectiveEl.textContent = `Guc: ${state.power}/3`;
  healthEl.textContent = `Saglik: ${state.health}/${state.maxHealth}`;
  statusEl.textContent = `Kapi: ${state.gateOpen ? "Acik" : "Kilitli"} | Canavar: ${state.enemyMode === "chase" ? "Kovaliyor" : "Dolasiyor"}`;
}

function updateCrosshair() {
  crosshairEl.classList.toggle("hidden", !state.running || state.paused || state.over || state.win || !isLocked());
}

function flashBeam(color, target) {
  state.beamTarget.copy(target);
  state.beamTimer = 0.16;
  beam.material.color.setHex(color);
  beam.visible = true;
}

function showToast(text, duration = 1.1) {
  state.toastText = text;
  state.toastTimer = duration;
  promptEl.textContent = text;
  promptEl.classList.remove("hidden");
}

